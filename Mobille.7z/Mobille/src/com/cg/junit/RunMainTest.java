package com.cg.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class RunMainTest {

	@Test
	void testCustomerDetails() {
		Assertions.assertEquals(true, true, "successful");
	/*	fail("Not yet implemented");*/
	}

}
